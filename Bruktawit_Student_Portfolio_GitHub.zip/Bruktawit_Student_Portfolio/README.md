# Bruktawit Ambacew — Student Portfolio

A simple, responsive student portfolio website made with HTML, CSS, and JavaScript.

## Included files
- `index.html` — website content
- `style.css` — design and mobile layout
- `script.js` — small year update

## Preview on your phone
Open `index.html` in a browser, or upload the website files to a GitHub repository.

## Publish with GitHub Pages
1. Open your GitHub repository.
2. Upload `index.html`, `style.css`, and `script.js` to the repository's main/root folder (not inside another folder).
3. Commit the changes.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch **main** and folder **/(root)**, then save.
7. Wait for GitHub Pages to publish the site.

Note: The PowerPoint presentation is a separate file. GitHub Pages needs website files such as `index.html`; uploading only a `.pptx` or `.zip` does not publish a website.

## Personalize it
Edit the text in `index.html` to add your own projects, achievements, and any contact details you choose to make public. Do not add private information.
